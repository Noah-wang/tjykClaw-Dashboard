import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'sonner';
import App from './App';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        richColors
        position="top-right"
        toastOptions={{
          style: {
            borderRadius: '18px',
            border: '1px solid rgba(34, 30, 24, 0.14)',
          },
        }}
      />
    </BrowserRouter>
  </React.StrictMode>,
);
